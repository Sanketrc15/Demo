package com.ems.model;

public class Employee {
private int id;
private String name;
@Override
public String toString() {
	return "Employee [id=" + id + ", name=" + name + ", surname=" + surname + ", job=" + job + "]";
}
private String surname;
private String job;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSurname() {
	return surname;
}
public void setSurname(String surname) {
	this.surname = surname;
}
public String getJob() {
	return job;
}
public void setJob(String job) {
	this.job = job;
}
	
}
