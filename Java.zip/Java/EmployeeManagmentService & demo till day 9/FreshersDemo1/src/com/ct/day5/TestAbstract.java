package com.ct.day5;

public class TestAbstract {

	public static void main(String[] args) {
		Admin admin=new Admin(101,"ram",5);
		System.out.println(admin.id+" "+admin.name+" "+admin.items);
		Admin admin1=new Admin(102,"rakhee",3);
		System.out.println(admin1.id+" "+admin1.name+" "+admin1.items);

		Employee emp=null;//new Employee();
		emp=new Admin();
		emp.work();
		Object obj=emp;
		System.out.println(obj);
		Flyer f=new Flyer() {};
		
		
	}

}

interface Flyer{
	
}


