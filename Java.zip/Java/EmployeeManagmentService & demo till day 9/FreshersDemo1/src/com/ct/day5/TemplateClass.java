package com.ct.day5;

import java.util.*;

public class TemplateClass {

	public static void main(String[] args) {
		List<String> lii=new ArrayList<>();
		
//	List<String> li=new ArrayList<>();
	List<String> li=new ArrayList<String>();
//	List<String> li=new ArrayList();
	
	li.add("hello");
	li.add("hello");
	li.add("hi");
	//li.add(100);
	li.add("hi hello");
	System.out.println(li);
	}

}
