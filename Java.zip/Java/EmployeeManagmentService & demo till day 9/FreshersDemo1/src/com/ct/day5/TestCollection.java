package com.ct.day5;

import java.util.*;

public class TestCollection {

	public static void main(String[] args) {
		//wrapper class - 9 , 8 dt,Void
		int a=1000;
		Integer i=new Integer(a);//boxing
		System.out.println(i);//autounboxing
		System.out.println(i.intValue());//unboxing
		List l=new ArrayList();
		l.add(10);
		l.add(10);//autoboxing
		l.add(new Integer(10));//boxing
		l.add(3.4f);
		l.add(1);
		l.add(20);
		l.add(100);
		l.add('c');
		l.add("hello");
		System.out.println(l);
		System.out.println(l.size());
		
		System.out.println("retrieve data from 3rd position : "+l.get(2));
		l.set(2,3456);
		System.out.println(l);
		l.add(2, "added");
		System.out.println(l);
		l.remove(2);
		System.out.println(l);
		l.remove(new Integer(3456));
		System.out.println(l);
		
		//l.clear();
		//l=null;
		System.out.println(l==null);
		//System.out.println(l.isEmpty()?"list empty":"not empty");
		
		List rawData=Arrays.asList(1,2,3,4,45,5,66);
		System.out.println(rawData);
		
		
		for(Object g:rawData)
		{
			System.out.println(g);
		}
		
		for(Object g:l)
		{
	//		System.out.println(g);
		}
		
		//Iterator
		//hasNext, next,remove
		Iterator it=l.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
			it.remove();//check condition or position and remove the data 
		}
		System.out.println(l);
		//CAE
		//CME
	}

}
