package com.ct.day5;

public class EmpServiceImpl implements IEmpService{

	IEmpDao dao=null;
	
	@Override
	public void add(Employee e) {
		dao=new EmpDaoImpl();
		dao.add(e);
	}

}
