package com.ct.day5;

import java.util.*;

public class SetEg {

	public static void main(String[] args) {
	//	Set s=new HashSet();
		/*Set s=new TreeSet();
		s.add(10);
		s.add(10);
		s.add(180);
		s.add(109);*/
	//	s.add('c');
		//s.add("hello");
//	System.out.println(s);
	
//	s.remove(new Integer(180));
	//System.out.println(s);
	//List iterator

	//	Set s=new TreeSet();
		Emp emp=new Emp();
		Set s=new LinkedHashSet();
		s.add(emp);
		s.add("hello");	
		s.add("Hello");
		s.add("alpha");
		s.add("Beta");
		s.add("bEta");
		s.add("CASPER");
		s.add("CASPER");
		System.out.println(s);
	}

}

class Emp{
	
}
