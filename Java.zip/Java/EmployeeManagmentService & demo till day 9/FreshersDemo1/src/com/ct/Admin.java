package com.ct;
/**
 * header comment
 * author,created by,modified by.....
 */
public class Admin {
	
	
	public static void main(String... args) 
	{
		int a=90;//local var
		int b=89;
		System.out.println("value of a is "+(a+b));	//compilation error
		
		float f=1.2f;
		System.out.println("float value is "+f);
		long l=9234567890L;
		System.out.println("long value is "+l);
		char val='A';
		System.out.println("char is "+val);
		
		
		System.out.println('j'+'a'+'v'+'a');
		System.out.println('j');
		System.out.println((int)'j');//explicit type conversion
		
		int data='c';
		System.out.println(data);//implicit type  conversion
		
		char ch=99; //  char ch= (char)99;
		System.out.println(ch);//implicit type  conversion
		
		int res=(int) (4.5f/2);
		System.out.println(res);
		
		float res1=(int) (4.5f/2);
		System.out.println(res1);
		
		float res2=('a'/2);
		System.out.println(res2);
		
		float res3=('a'%2);
		System.out.println(res3);
		
//		int res4=10/0;
	//	System.out.println(res4);
		
		float res5=10.0f/0.0f;
		System.out.println(res5);
		System.out.println('\u0000');
		System.out.println('\u0780');
		
		System.out.println("hi"+5+(-5));
//		System.out.println("hi");
		System.out.println("hi");
		
	/*	for(;;System.out.println("hi")) {
			
		}*/
	}

}
//single
/*class Employee{
	int empId=1;
	String password="dummy";
	
}*/
