package com.ct.day2;

public class Human extends Primate{
//eat, walk,jump
	public void think() {
		System.out.println("i can think!!!");
	}
	public void talk() {
		System.out.println("i can talk!!!");
	}
}
