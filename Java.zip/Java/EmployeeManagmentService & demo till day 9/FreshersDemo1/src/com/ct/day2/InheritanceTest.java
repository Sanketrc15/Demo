package com.ct.day2;

import java.util.Scanner;

public class InheritanceTest {

	public static void main(String[] args) {
	/*Human human1=new Human();
	
	human1.jump();
	human1.eat();
	//human1.walk();
	human1.talk();
	human1.think();
	Primate p=new Primate();
	p.eat();
	//p.walk();
	p.jump();
	//p.think();
	//p.talk();
	
	*/
		
		//Scanner scan=new Scanner(System.in);
//		Scanner scan1=new Scanner("hi hello 123");// default delimiter " "
//		String s1=scan1.next();
//		String s2=scan1.next();
//		String s3=scan1.next();
//	//	int numb=scan1.nextInt();
	//	System.out.println(s1+"  "+s2+" "+s3);
		/*Scanner scan1=new Scanner("mon-tue-wed-thu,fri,sat,sun").useDelimiter("-");
				
		
	//	String s1=scan1.next();
		//String s2=scan1.next();
		while(scan1.hasNext()) {
			System.out.println(scan1.next());
		}
		*/
//		
//		Scanner scan1=new Scanner("hi hello how are you").useDelimiter("h");
//		while(scan1.hasNext()) {
//		System.out.println(scan1.next());
//		}
		String s1="hello";//scp
		String s2="hello"; 
		String s3=new String("hello");
		//System.out.println(s1.hashCode());
		//System.out.println(s2.hashCode());
		//System.out.println(s3.hashCode());
		//== is used forchecking reference ie memory
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		//equals is used for checking the value
		System.out.println("s1 hashcode "+s1.hashCode());
		System.out.println(s1.equals(s3));
		s1=s1.concat(" world");
		System.out.println("now mem is "+s1.hashCode());
		System.out.println("after concat "+s1);
		
		String data="alphabets";
		char arr[]=data.toCharArray();
		//enhanced for loop - AIOBE
		//for(dest:src)
		//src- contains many value -arr
		//dest can hold only one - char
		for(char d:arr) {
			System.out.println(d);
		}
		
		String days="mon tue wed";
		String ss[]=days.split(" ");
		
		for(String h :ss) {
			System.out.println(h);
		}
		
	}

}
