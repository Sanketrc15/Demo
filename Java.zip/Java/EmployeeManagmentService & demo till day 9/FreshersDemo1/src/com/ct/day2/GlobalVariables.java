package com.ct.day2;

public class GlobalVariables {

	int a=1;
	static int b=2;
	
	public static void main(String[] args) {
	
		GlobalVariables object1=new GlobalVariables();
		GlobalVariables object2=new GlobalVariables();
		GlobalVariables object3=new GlobalVariables();
		
		System.out.println("value of a is "+ (++object1.a));//2
		System.out.println("value of a is "+ (++object2.a));//2
		System.out.println("value of a is "+ (++object3.a));//2
		System.out.println("value of b by obj1 "+ (++object1.b));//3
		System.out.println("value of b by obj2 "+ (++object2.b));//4
		System.out.println("value of b by obj3 "+ (++object3.b));//5
		System.out.println(b);
		System.out.println("object 1 is viewing the data in b "+object1.b);
		System.out.println(GlobalVariables.b);
		
	}

}
