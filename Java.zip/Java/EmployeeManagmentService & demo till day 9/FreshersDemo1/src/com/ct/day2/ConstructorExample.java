package com.ct.day2;

public class ConstructorExample {

	public static void main(String[] args) {
		

	}

}



