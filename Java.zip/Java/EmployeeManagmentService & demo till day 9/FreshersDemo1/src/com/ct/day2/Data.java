package com.ct.day2;

public class Data {

	public static void main(String[] args) {
		Data d=new Data();
		System.out.println(d);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();//"hi hello!!!";
	}
}
