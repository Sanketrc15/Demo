package com.ct.day7;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
//public abstract interface java.io.Closeable extends java.lang.AutoCloseable {
import java.io.Closeable;
import java.lang.AutoCloseable;

public class ExceptionDemo1 {
	Reader r=null;
	static InputStreamReader isr=null;
	//use of try with resources from JAVA7 - eliminates finally blocks
	//arg passed to try should be Autocloseable resources or closeable
	//resources will be opened in same order but will be cloased in reverse order
	//resources are nothing but normal class objects which ll implement autocloaseable interface
	//they get close method by the help of this interface
	public static void main(String[] args) {
		
		try(A ob=new A();B ob1=new B()){
			
		}
		catch(Exception ioe) {
			System.out.println(ioe.getMessage());
		}
		finally {}
		/*finally {
			if(isr!=null) {
				try {
					isr.close();
				} catch (IOException e) {
					
				}	
			}
			isr=null;
		}*/
		System.out.println("executed...");
	}

}
class A implements AutoCloseable
{
	A(){
		System.out.println("ob a is created");
	}

	@Override
	public void close() throws NullPointerException {// TODO Auto-generated method stub
		
		System.out.println("ob A is closed");
		}

	

}
class B implements AutoCloseable
{
	B(){
		throw new ArithmeticException();
		//System.out.println("ob B is created");
	}

	@Override
	public void close() throws NullPointerException {// TODO Auto-generated method stub
		System.out.println("ob B is closed");
	}
	

}