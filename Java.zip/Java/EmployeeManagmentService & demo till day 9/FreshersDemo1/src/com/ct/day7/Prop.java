package com.ct.day7;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;

public class Prop {

	public static void main(String[] args) throws IOException {
	/*	Properties p=new Properties();
		Properties p=System.getProperties();
		System.out.println(p);
		System.out.println(p.getProperty("sun.desktop"));
		System.out.println(p.getProperty("awt.toolkit"));
		p.put("key1", "value1");
		p.put("key2", "value2");
		p.put("key3", "value3");
		Set r=p.keySet();
		System.out.println(r);
		Collection col=p.values();
		System.out.println(col);
		Map m=p;
		Set s=m.entrySet();
//		Map.Entry;
		for(Object ent:s)
		System.out.println(ent);*/
		
		/*Map map1=new HashMap();
		map1.put("hello", "1");
		map1.put("hi", "2");
		map1.put("hit", "3");
		Set<Map.Entry> setData=map1.entrySet();
		for(Map.Entry mObj:setData)
		{
			System.out.println(mObj);
		}*/
		FileInputStream fis=new FileInputStream("connection_prop.properties"); 
        Properties prop=new Properties (); 
        prop.load (fis); 
        
        System.out.println(prop);
        System.out.println(prop.getProperty("name"));
        /*String HOME = System.getProperty("user.home");
        System.out.println(HOME);
        Paths.get("C:", "Users","kathiresann");
      Path p1=  Paths.get("C:", "Users","kathiresann","C\\Users\\a.txt");
      System.out.println(p1);
      System.out.println(UUID.randomUUID());
      
      String prefix = "log_";
      String suffix = ".txt";
      Path p2 = Paths.get(HOME + "/");
      Files.createTempFile(p2, prefix, suffix);*/
      
	}

}
