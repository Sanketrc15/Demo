package com.ct.day6;

import java.util.*;
import java.util.Map;

public class MapEx {

	public static void main(String[] args) {
		//Map m=new HashMap();
		Map m=new Hashtable();
		m.put(1,"one");
		m.put(2,"two");
		m.put(2,"two");
		m.put('3',3.0f);
		m.put(2,"updated");
		m.put(4,"updated");
		m.put(null, "yes");
		m.put(null, "no");//duplication
		
		System.out.println(m);
		
	/*	Employee emp1=new Employee();
		emp1.setEmpId(1001);emp1.setName("aaa");
		Employee emp2=new Employee();
		emp2.setEmpId(1002);emp2.setName("bbb");
		Employee emp3=new Employee();
		emp3.setEmpId(1003);emp3.setName("ccc");
		
		Map<Integer,Employee> empList=new HashMap();
		empList.put(emp1.getEmpId(), emp1);
		empList.put(emp2.getEmpId(), emp2);
		empList.put(emp3.getEmpId(), emp3);
		System.out.println(empList);
		
*/		
	}

}
class Employee{
	int empId;
	String name;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + "]";
	}
	
	
}