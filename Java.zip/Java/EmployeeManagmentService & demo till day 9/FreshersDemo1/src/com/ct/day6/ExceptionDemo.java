package com.ct.day6;

import java.io.IOException;
import java.io.InputStreamReader;

public class ExceptionDemo {
public void disp() {}
	public static void main(String[] args)  {
		try 
        {
            errorMethod();  
            System.out.print("A"); 
        }  
        catch (Exception ex) 
        {
            System.out.print("B");  
        } 
        finally 
        {
            System.out.print("C"); 
        } 
        System.out.print("D"); 
    }  
    public static void errorMethod() 
    {
        throw new Error(); /* Line 22 */
    } 

		/*int a=0,b=90;
		int result=0;
		ExceptionDemo e=null;
		try { //creates the obj of exception occuring and throw
//			scanner obj
		//result=b/a;
		//System.out.println(result);
			//e.disp();
			
			new InputStreamReader(System.in).read();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally {
			//is to clean the resources initialized in the constr or prog
			//by setting the value to null
			System.out.println("in finally");
		}*/
		/*catch(ArithmeticException | NullPointerException | ArrayIndexOutOfBoundsException c) {
			 
			if(c instanceof NullPointerException) {
				System.out.println("obj noit initialized...");
			}
			else {
			System.out.println(c.getMessage());
			}
			//c.printStackTrace();
		}*/
		/*catch(NullPointerException c) {
		
			System.out.println("obj is not initialized...exception occured ");
			//c.printStackTrace();
		}*/
		/*catch(Exception c) {
			System.out.println(c);
			System.out.println("exception occured ");
			//c.printStackTrace();
		}
		catch(Throwable c) {
			System.out.println(c);
			System.out.println("exception occured ");
			//c.printStackTrace();
		}*/
		/*finally {
			//is to clean the resources initialized in the constr or prog
			//by setting the value to null
			System.out.println("in finally");
		}*/
	//	System.out.println("normal flow of prog");
		}

//}
