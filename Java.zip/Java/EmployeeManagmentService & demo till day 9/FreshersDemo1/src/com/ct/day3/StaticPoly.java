package com.ct.day3;

public class StaticPoly {
//overloading 
	//method
	//constructor
	public static void main(String[] args) {

	}

	public void display() {

	}

	public void display(int a) {

	}
	public int display(float a) {
		return 0;
	}
	public void display(int b,float c) {

	}
	public void display(float t,int r) {

	}
}
