package com.ct.day3;

public interface IContract1 {

	public static final int NO_OF_DAYS=30;
	public abstract void trainingJava();
	public abstract void trainingJsp();
}
