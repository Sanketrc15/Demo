package com.ct.day3;

public class Electronics {

	void powerOn() {
		System.out.println("powered on...");
	}
	void powerOff() {
		System.out.println("powered off...");
	}
}
