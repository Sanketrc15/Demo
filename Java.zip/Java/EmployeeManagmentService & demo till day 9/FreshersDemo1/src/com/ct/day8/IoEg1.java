package com.ct.day8;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.DosFileAttributes;
//symbolic link

public class IoEg1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		final String FILE_NAME="a.txt";
		/*File f=new File(FILE_NAME);
		f.createNewFile();
		System.out.println("flie got created");
		String HOME = System.getProperty("user.home");
		System.out.println(HOME);*/
		//Files
		String HOME = System.getProperty("user.home");
		/*	Path p=Paths.get(HOME+"/a.txt");//+"/my files/a.txt");
	//	Path p=Paths.get("C:\\Users\\kathiresann\\Desktop\\my files\\a.txt");
		Path f=Files.createFile(p);//java.nio.file.AccessDeniedException
		System.out.println(f+" created ");*/
		
		//Path p=Paths.get(HOME+"/directory1");
		/*Path p=Paths.get(HOME+"/directory2/directory3");
		//Files.createDirectory(p);
		Files.createDirectories(p);
		System.out.println("directory created ");
*/	
	//	Path p=Paths.get(HOME+"/directory2/directory3/b.txt");
		Path p1=Paths.get(HOME+"/directory2/directory3/a.txt");
		//Files.createFile(p);
		System.out.println("got created ");
		//System.out.println(Files.isDirectory(p));
		//System.out.println(Files.isReadable(p));
		//System.out.println(Files.isWritable(p));
		Files.delete(p1);
	//	Files.delete(p);
		
		
		
	}

}

