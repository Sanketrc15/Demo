package com.ct.day9;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map.Entry;

public class SqlDemo1 {

	public static void main(String[] args) throws SQLException {
		int id=1001;
		String s="mukund";
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");  
	//	String qry="SELECT * FROM Employee WHERE emp_id="+id+" and emp_name='"+s+"'";
		String qry="SELECT * FROM Employee WHERE emp_id=?";
		System.out.println(qry);
		//Statement st= con.createStatement();
		PreparedStatement st=con.prepareStatement(qry);//qry is compiled
		st.setInt(1,id);
		ResultSet rs=st.executeQuery();
		rs.next();
		System.out.println(rs.getString(3));
	
		st.setInt(1,1004);
		ResultSet rs1=st.executeQuery();
		rs1.next();
		System.out.println(rs1.getString(3));
		st.setInt(1,1003);
		ResultSet rs2=st.executeQuery();
		
		rs2.next();
		System.out.println(rs2.getString(3));
	}	

}

class Empl{
	int empid;
	String name;
	String surName;
	String job;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	@Override
	public String toString() {
		return "Empl [empid=" + empid + ", name=" + name + ", surName=" + surName + ", job=" + job + "]";
	}
	
	
	
}
