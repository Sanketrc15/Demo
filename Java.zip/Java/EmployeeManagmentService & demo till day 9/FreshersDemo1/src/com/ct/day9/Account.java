package com.ct.day9;

import java.io.Serializable;

public class Account implements Serializable {

	//private static final long serialVersionUID = 1L;
	private int accId;
	private String accName;
	private transient float balance;
	private static String tempSecToken;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public int getAccId() {
		return accId;
	}

	public void setAccId(int accId) {
		this.accId = accId;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public static String getTempSecToken() {
		return tempSecToken;
	}

	public static void setTempSecToken(String tempSecToken) {
		Account.tempSecToken = tempSecToken;
	}

	public Account(int accId, String accName, float balance) {
		this.accId = accId;
		this.accName = accName;
		this.balance = balance;
	}
	/*static {
		tempSecToken="1234Abc";
	}*/
	@Override
	public String toString() {
		return "Account [accId=" + accId + ", accName=" + accName + ", balance=" + balance +"temp token "+ tempSecToken+"]";
	}
	
	
}
