package propertiesfile;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
public class AdminFile {
	public static void main(String args[]) {
		Properties prop = new Properties();
		try {			
			
			prop.setProperty("admin", "admin");
			
			prop.store(new FileOutputStream("admin.properties"), null);
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}
}

