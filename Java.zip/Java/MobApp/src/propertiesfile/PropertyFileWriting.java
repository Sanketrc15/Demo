package propertiesfile;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
public class PropertyFileWriting {
	public static void main(String args[]) {
		Properties prop = new Properties();
		try {			
			
			prop.setProperty("kamlesh", "kamlesh");
			prop.setProperty("ankit", "ankit");
			prop.setProperty("aditya", "aditya");
			prop.setProperty("sanket", "sanket");
			prop.setProperty("pranav", "pranav");
			prop.setProperty("onkar", "onkar");
			
			prop.store(new FileOutputStream("user.properties"), null);
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}
}
