package com.cd.services;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import com.cd.dao.IMobileDAO;
import com.cd.dao.MobileDaoImpl;
import com.cd.exception.MobException;
import com.cd.model.Mobile;



public class MobileServiceImpl implements IMobileService {

	IMobileDAO dao = new MobileDaoImpl();
	static Boolean bool = false; 
	
	/*@Override
	public Mobile addMobile(Mobile m) {
		return m;
		
		
	}

	@Override
	public Mobile deleteMobile(int mId) {
		return null;
		
		
	}

	@Override
	public Mobile updateMobileDetails(int mId) {
		return null;
		
	}*/

	@Override
	public Mobile searchMobileById(int Id) throws MobException{
		
		return dao.searchMobileById(Id);	
	
		
		
	}

	public Boolean Validation(String a,String b,String c) throws MobException{
		try{
			Properties p=new Properties();
			
			if("Admin".equals(a) && "admin".equals(b)){
				FileReader reader=new FileReader("C:/Users/SanketC2/Desktop/Java/MobApp/admin.properties");  
				p.load(reader);  
		     bool = p.getProperty(b).equals(b);
		    
			}
			
			if("User".equals(a) && c.equals(b)){
				FileReader reader=new FileReader("C:/Users/SanketC2/Desktop/Java/MobApp/user.properties");  
				p.load(reader);  
		     bool = p.getProperty(b).equals(b);
			}
			
			
		}catch(FileNotFoundException e){
			
			throw new MobException("Not valid login ID and password.....");
			
		} catch (IOException e) {
			System.out.println("IO exception......");
			}
		return bool;
	}
}


