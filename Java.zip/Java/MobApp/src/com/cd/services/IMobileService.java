package com.cd.services;

import com.cd.exception.MobException;
import com.cd.model.Mobile;

public interface IMobileService {

	/*public Mobile addMobile (Mobile m);
	public Mobile deleteMobile(int mId);
	public Mobile updateMobileDetails(int mId);*/
	public Mobile searchMobileById(int mId) throws MobException;

	public Boolean Validation(String category, String un, String pwd) throws MobException;
	
}