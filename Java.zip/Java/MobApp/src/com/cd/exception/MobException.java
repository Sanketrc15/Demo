package com.cd.exception;

public class MobException extends Exception {

	public MobException() {
		// TODO Auto-generated constructor stub
	}
	
	public MobException(String s) {
		 super(s);
	}

}
