package com.cd.model;

public class Mobile {
	private String name;
	private String description;
	private int id;
	private float price;

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getId() {
		return id;
	}

	public float getPrice() {
		return price;
	}

	

	public Mobile() {
		// TODO Auto-generated constructor stub
	}

	public Mobile(String name, String description, int id, float price) {
		this.name = name;
		this.description = description;
		this.id = id;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Mobile [name=" + name + ", description=" + description + ", id=" + id + ", price=" + price + "]";
	}
	
}
