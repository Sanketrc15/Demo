package com.cd.ui;
import java.util.Scanner;

import com.cd.exception.MobException;
import com.cd.model.Mobile;
import com.cd.services.*;
//import com.cd.services.MobileServiceImpl;
public class Client {
	
	static Boolean bool = false;
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		System.out.println("-----------Select the login category-----------");
		System.out.println("1.Admin        2.User ");
		String category = sc.next();
		System.out.println("Enter username and password");
		
		
		String un = sc.next();
		String pwd = sc.next();
		
		IMobileService ims = null;
		ims = new MobileServiceImpl();
		Mobile m = null;
		
		try{
		bool = ims.Validation(category,un,pwd);
		if(bool==true){
			System.out.println("----------Welcome to the Mobile Gallery--------");	
		}else
			System.out.println("Incorrect login credentials");
		}catch(Exception e){		//------exception??
			System.out.println(e.getMessage());
		}
		
		while(bool){
			
			System.out.println("1. Add Mobile");
			System.out.println("2. Search Mobile by ID");
			System.out.println("3. Display all Mobiles");
			System.out.println("4. Delete Mobile");
			System.out.println("5. Exit");
			int num = sc.nextInt();
			int id = 0;
		switch(num){
		
		case 1:
		{
			System.out.println("Enter the Mobile Name, Mobile Description, Mobile ID, Mobile Price ");
			String n = sc.next();
			String d = sc.next();
			int i = sc.nextInt();
			float p = sc.nextFloat();
			Mobile m1 = new Mobile(n,d,i,p); 
			
			
			
		}
		
		case 2:
		{
			System.out.println("Enter the Mobile ID");
			id = sc.nextInt();
			try{
				
				m = ims.searchMobileById(id);
				System.out.println(m);
			}catch(MobException e){
				System.out.println(e.getMessage());
			}
			
			//m.getId();
		}
			
		case 3:
		{
			
		}
		
		case 4:
		{
			
		}
		
		default:
		{
			System.exit(0);
		}
		
		
		}
		}
		
	}

}
