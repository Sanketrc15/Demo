package com.cd.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cd.exception.MobException;
import com.cd.model.Mobile;

public class MobileDaoImpl implements IMobileDAO{

	Mobile m = new Mobile();
	
	public void addMobile(Mobile m) {
		
		
	}

	public void deleteMobile(int mId) {
		
		
	}

	
	public void updateMobileDetails(int mId) {
		
		
	}

	@Override
	public Mobile searchMobileById(int Id) throws MobException {
		try{
			Connection con = DriverManager.getConnection("");
			String query = "Select * from Mobile Where Id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1,Id);
			ResultSet rs = ps.executeQuery();
				
			if(rs.next()){
				m.setName(rs.getString(1));
				m.setDescription(rs.getString(2));
				m.setId(rs.getInt(3));
				m.setPrice(rs.getInt(4));
			}
		}catch(SQLException s){		//sqlexception ???
			throw new MobException("connection not established............");
		}
		return m;
	}

}