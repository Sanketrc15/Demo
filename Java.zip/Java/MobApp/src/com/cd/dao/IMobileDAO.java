package com.cd.dao;

import com.cd.exception.MobException;
import com.cd.model.Mobile;

public interface IMobileDAO {
	
	public void addMobile(Mobile m);
	public void deleteMobile(int mId);
	public void updateMobileDetails(int mId);
	public Mobile searchMobileById(int mId) throws MobException;
	
}
