package com.ct.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ct.entity.Book;


public class MovieDao {
	
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public Book getBook(int id) {
		Book mov=null;
		String sql="SELECT * FROM booktable where Id=?";
		mov=(Book) jdbcTemplate.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper(Book.class));
		return mov;
	}

	public Book addBook(Book book) {
		String sql="Insert into booktable Values (?,?,?,?,?)";
		jdbcTemplate.update(sql,book.getId(),book.getBookName(),book.getPublisher(),book.getPrice(),book.getThumbnail());
	return book;
	}

	public Book editBook(Book book) {
		String sql="update booktable Set Id=? , BookName=?, Publisher=?, Price=?, Thumbnail=? where Id= ?";
		jdbcTemplate.update(sql,book.getId(),book.getBookName(),book.getPublisher(),book.getPrice(),book.getThumbnail(),book.getId());
	return book;
	}

	public void deleteBook(int id) {

		String sql="DELETE FROM booktable where Id=?";
		jdbcTemplate.update(sql,id);
		
	}

	public List<Book> getAllBook() {
		java.util.List<Book> booklist = new ArrayList<Book>();
		String sql="SELECT * FROM booktable";
		booklist= jdbcTemplate.query(sql,new BeanPropertyRowMapper(Book.class));
		return booklist;
	}
}
//