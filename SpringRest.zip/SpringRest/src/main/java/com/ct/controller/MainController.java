package com.ct.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ct.dao.MovieDao;
import com.ct.entity.Book;

@RestController
public class MainController {

	@RequestMapping(value="/")
	public String getHome() {
		return "index";
	}
			
	@RequestMapping(value="/book", method=RequestMethod.GET)
	public Book getBook(@RequestParam("id") int id) {
		
		ApplicationContext ctx=null;
		//ModelAndView mv = new ModelAndView();
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");        
        MovieDao dao=(MovieDao)ctx.getBean("mdao");
       // mv.addObject("movie", dao.getBook(id));
       // mv.setViewName("index");
        return dao.getBook(id);
		
	}
	
	@RequestMapping(value="/books", method=RequestMethod.GET)
	public List<Book> getAllBook() {
		
		ApplicationContext ctx=null;
		//ModelAndView mv = new ModelAndView();
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");        
        MovieDao dao=(MovieDao)ctx.getBean("mdao");
       // mv.addObject("movie", dao.getBook(id));
       // mv.setViewName("index");
        return dao.getAllBook();
		
	}
	
	@RequestMapping(value="/book", method=RequestMethod.POST)
	public Book addBook(@RequestBody Book book) {
		System.out.println(book.getBookName());
		ApplicationContext ctx=null;
		//ModelAndView mv = new ModelAndView();
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");        
        MovieDao dao=(MovieDao)ctx.getBean("mdao");
       // mv.addObject("movie", dao.getBook(id));
       // mv.setViewName("index");
        return dao.addBook(book);
		
	}
	
	@RequestMapping(value="/book", method=RequestMethod.PUT)
	public Book updateBook(@RequestBody Book book) {
		System.out.println(book.getBookName());
		ApplicationContext ctx=null;
		//ModelAndView mv = new ModelAndView();
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");        
        MovieDao dao=(MovieDao)ctx.getBean("mdao");
       // mv.addObject("movie", dao.getBook(id));
       // mv.setViewName("index");
        return dao.editBook(book);
		
	}
	
	@RequestMapping(value="/book", method=RequestMethod.DELETE)
	public void daleteBook(@RequestParam("id") int id) {
		
		ApplicationContext ctx=null;
		//ModelAndView mv = new ModelAndView();
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");        
        MovieDao dao=(MovieDao)ctx.getBean("mdao");
       // mv.addObject("movie", dao.getBook(id));
       // mv.setViewName("index");
        dao.deleteBook(id);
		
	}
}
